function Add-Numbers($a, $b) {
    return $a + $b
}
